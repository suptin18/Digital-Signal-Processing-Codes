clc;
clear all;
close all;

N = 16;
xn = [1 1 0];
xk = fft(xn, N);

disp('N point of DFT of x(n) is = ');
disp(xk);

subplot(2,2,1);
n = 0:length(xn)-1;
stem(n, xn);
xlabel('n');
ylabel('x(n)');
title('Original Signal');

k = 0:N-1;
subplot(2,2,2);
stem(k, abs(xk));
xlabel('k');
ylabel('|X(k)|');
title('Magnitude Spectrum');

subplot(2,2,3);
stem(k, angle(xk));
xlabel('k');
ylabel('?X(k)');
title('Phase Spectrum');
