clc;
clear all;
close all;

x=[1 2 3 4];
y=[1 2 1 2];
r=conv(x,fliplr(y));
disp('Cross Corelation Output');
disp(r);
%Plot the input signal
n1=length(x)-1;
t1=0:n1;
subplot(2,2,1);
stem(t1,x);
xlabel('n');
ylabel('X(n)');

%Plot the input signal
n2=length(y)-1;
t2=0:n2;
subplot(2,2,2);
stem(t2,y);
xlabel('n');
ylabel('y(n)');
%Plot the output signal
k=-n2:n1;
subplot(2,2,3);
stem(k,r);
xlabel('n');
ylabel('Rxy');
title('Cross Correlation Output');
