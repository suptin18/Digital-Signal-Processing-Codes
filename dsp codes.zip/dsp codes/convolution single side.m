x1 = [1 2 3 1]; % Input signal x1
x2 = [1 2 1 -1]; % Input signal x2

yn = conv(x1, x2); % Perform convolution

disp('After convolution:');
disp(yn);

n = 0:length(yn)-1; % Indexing assuming non-negative range

subplot(3,1,1);
stem(0:length(x1)-1, x1, 'filled');
xlabel('n');
ylabel('x1(n)');
title('Input Signal x1(n)');

subplot(3,1,2);
stem(0:length(x2)-1, x2, 'filled');
xlabel('n');
ylabel('x2(n)');
title('Input Signal x2(n)');

subplot(3,1,3);
stem(n, yn, 'filled');
xlabel('n');
ylabel('y(n)');
title('Single-Sided Convolution Output y(n)');
