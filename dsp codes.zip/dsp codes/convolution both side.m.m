x1 = [-1 0 1 2 3]; % Input signal x1
x2 = [-2 -1 0 1 2]; % Input signal x2

n1 = -1:3; % Time indices for x1
n2 = -2:2; % Time indices for x2

yn = conv(x1, x2); % Perform convolution

ybegin = n1(1) + n2(1); % Starting index of y(n)
yend = n1(end) + n2(end); % Ending index of y(n)
ny = ybegin:yend; % Time index for output signal

disp('After convolution final signal: ');
disp(yn);

subplot(3,1,1);
stem(n1, x1, 'filled');
xlabel('n');
ylabel('x1(n)');
title('Input Signal x1(n)');

subplot(3,1,2);
stem(n2, x2, 'filled');
xlabel('n');
ylabel('x2(n)');
title('Input Signal x2(n)');

subplot(3,1,3);
stem(ny, yn, 'filled');
xlabel('n');
ylabel('y(n)');
title('Both-Sided Convolution Output y(n)');
