clc;
clear all;
close all;

N = 16;
i = sqrt(-1);

xn = [1 1 0 1 1 1 1 1 0 1 0 0 1 0 1 1];
%xk = fft(xn, N);
xk = zeros(1,N);
for k =0:1:N-1;
    for n=0:1:N-1;
        xk(k+1)=xk(k+1)+xn(n+1)*exp(-i*2*pi*k*n/N);
    end
end

disp('N point of DFT of x(n) is = ');
disp(xk);

subplot(2,2,1);
n = 0:length(xn)-1;
stem(n, xn);
xlabel('n');
ylabel('x(n)');
title('Original Signal');

k = 0:N-1;
subplot(2,2,2);
stem(k, abs(xk));
xlabel('k');
ylabel('|X(k)|');
title('Magnitude Spectrum');

subplot(2,2,3);
stem(k, angle(xk));
xlabel('k');
ylabel('?X(k)');
title('Phase Spectrum');
