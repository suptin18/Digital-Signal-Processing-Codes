clc;
clear all;
close all;

x=input('Input the sequence of x(n)');
y=input('Input the sequence of y(n)');
nx1 = input('Input the starting index of X(n)');
ny1 = input('Input the starting index of y(n)');

r=conv(x,fliplr(y));
disp('Cross Corelation Output');
disp(r);

%Plot the input signal
n1=length(x)-1;
nx = nx1:nx1+n1;
subplot(2,2,1);
stem(nx,x);
xlabel('n');
ylabel('X(n)');

%Plot the input signal
n2=length(y)-1;
ny= ny1:ny1+n2;
subplot(2,2,2);
stem(ny,y);
xlabel('n');
ylabel('y(n)');

%Plot the output signal
start = nx1-ny(end);
end1 = nx(end)-ny1;
k=start:end1;
subplot(2,2,3);
stem(k,r);
xlabel('n');
ylabel('Rxy');
title('Cross Correlation Output');
